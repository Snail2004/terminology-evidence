# EV-02 D0 Blind Cohort — Producer-Safe Handoff

Use these exact bytes for Main/System Integration/C cohort binding.

This package contains no gold label, reviewer decision, candidate rank, winner,
expected result, split assignment or aggregate label distribution.

It is not a RUN_AUTHORIZED receipt and does not open gold.
