# Blind Stage A review

Use only `blind_cases.csv` and `blind_contexts.csv`. Do not inspect glossary priority, model definition/POS/confidence, or another reviewer output. Fill exactly one reviewer sheet independently. Allowed split decisions: `NO_SPLIT`, `SPLIT`, `UNJUDGEABLE`. Set `review_status=REVIEWED` only after all fields are complete.
