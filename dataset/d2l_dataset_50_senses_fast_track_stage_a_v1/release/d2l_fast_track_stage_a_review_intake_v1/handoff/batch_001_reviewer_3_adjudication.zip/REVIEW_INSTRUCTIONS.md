# Reviewer 3 adjudication instructions

Resolve each case from the D2L evidence and the two independent reviews. R4 cases require a decision even when the reviewers agree. Fill only `adjudication`; preserve every other byte-level field. For candidate replacements, return objects with exactly `candidate_id`, `candidate_slot`, and `replacement_target_vi`; do not return unbound strings. Set review_status and adjudication_status to COMPLETE. Do not create Stage B gold or a final glossary decision.
