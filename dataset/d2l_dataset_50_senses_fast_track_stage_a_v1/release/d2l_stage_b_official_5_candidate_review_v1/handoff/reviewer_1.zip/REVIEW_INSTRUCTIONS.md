# Stage B candidate review instructions

Review each candidate independently using the supplied sense definition and D2L contexts. Fill only `review`. Allowed candidate_gold_label values are ACCEPT, CONDITIONAL, REJECT, SPLIT_REQUIRED, HUMAN_UNJUDGEABLE. Use positive_context_refs only for same-sense real contexts; synthetic contexts are boundary-only. Do not use C/E/Global output, intended candidate roles, or another reviewer's label. Preserve all source fields and hashes. Set review_status=COMPLETE and return only the completed JSON.
