Review Stage B official 5 candidates as reviewer_2. Return only the completed review_input.json file and do not inspect any other reviewer output.
