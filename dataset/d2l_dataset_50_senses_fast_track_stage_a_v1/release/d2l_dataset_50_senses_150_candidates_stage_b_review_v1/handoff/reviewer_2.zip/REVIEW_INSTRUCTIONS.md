# Stage B dual candidate review

Review all supplied cases as reviewer_2, independently.

Use only the supplied English sense, Vietnamese candidate, and D2L source contexts. Do not infer or record an intended candidate role. Fill only the `review` object. Choose exactly one candidate_gold_label from ACCEPT, CONDITIONAL, REJECT, SPLIT_REQUIRED, HUMAN_UNJUDGEABLE. Use positive_context_refs only for supplied real same-sense contexts. Synthetic/boundary contexts are not positive evidence. Preserve every source field and hash; do not change case IDs, candidate IDs, or context text. Set review_status=COMPLETE and return the same JSON structure.

Do not open or rely on any other reviewer's file. This is a Stage B review only; do not assign final gold, C/E results, or final glossary decisions.
