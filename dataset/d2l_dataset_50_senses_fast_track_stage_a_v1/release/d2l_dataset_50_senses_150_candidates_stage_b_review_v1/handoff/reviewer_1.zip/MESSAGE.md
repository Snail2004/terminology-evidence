Return the completed reviewer_input_full.json as reviewer_1. Do not return raw prose or alter source fields.
