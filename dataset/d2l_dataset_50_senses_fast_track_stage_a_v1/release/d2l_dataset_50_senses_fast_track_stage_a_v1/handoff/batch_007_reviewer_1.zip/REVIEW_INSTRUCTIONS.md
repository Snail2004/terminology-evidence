# Stage A review instructions

Review each sense independently from the supplied D2L evidence. Fill only the fields inside `review`; do not change `source_payload` or `source_payload_sha256`. Synthetic rows are boundary-only and must never be used as positive evidence. Return only the completed `review_input.json`.

Allowed standard decisions: ACCEPT, REVISE, UNJUDGEABLE. Allowed sense statuses: READY_FOR_CONTRACT_CONSTRUCTION, REVISION_REQUIRED, SPLIT_REQUIRED, UNRESOLVED, QUARANTINED. Set review_status=COMPLETE.
