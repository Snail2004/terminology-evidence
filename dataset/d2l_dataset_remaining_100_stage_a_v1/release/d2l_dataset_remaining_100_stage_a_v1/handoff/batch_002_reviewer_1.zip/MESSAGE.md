Review batch_002 as reviewer_1. Return only the completed review_input.json.
