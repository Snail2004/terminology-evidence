Review batch_003 as reviewer_1. Return only the completed review_input.json.
