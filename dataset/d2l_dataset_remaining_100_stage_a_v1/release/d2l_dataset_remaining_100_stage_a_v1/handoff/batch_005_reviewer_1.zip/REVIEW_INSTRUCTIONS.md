# D2L remaining-100 Stage A review

You are reviewer_1. Review only the supplied cases and work independently.

Evaluate the proposed English sense definition, part of speech, scope, candidate set, and source-grounded evidence. Use only the supplied D2L contexts. A synthetic or boundary context is not positive evidence. Fill only the `review` object; preserve all source fields, IDs, text, and hashes. Set review_status=COMPLETE and provide a nonblank review_notes value. Do not assign Stage B gold, C/E results, or a final glossary decision. Do not inspect another reviewer's output.

Allowed decisions: ACCEPT, REVISE, UNJUDGEABLE. Allowed sense statuses: READY_FOR_CONTRACT_CONSTRUCTION, REVISION_REQUIRED, SPLIT_REQUIRED, UNRESOLVED, QUARANTINED. Return the same JSON structure with only review fields completed.
