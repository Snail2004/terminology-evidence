Review batch_004 as reviewer_1. Return only the completed review_input.json.
