# Reviewer 1 Stage B repair

This pack contains exactly one previously reviewed case. Fill only the `repair` object. Keep the original SPLIT_REQUIRED label and every source/review field unchanged. Enter a nonblank `allowed_scope` that states the D2L scope affected by the split, optionally add repair_notes, and set repair_status=COMPLETE. Return the same JSON structure as reviewer_1_repair.json. Do not call a provider or assign final gold.
