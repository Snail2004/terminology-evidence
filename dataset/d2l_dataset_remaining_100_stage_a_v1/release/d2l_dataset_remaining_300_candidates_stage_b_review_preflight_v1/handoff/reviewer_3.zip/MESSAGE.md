Complete every case in reviewer_3_adjudication_input.json and return the same structure as reviewer_3.json. Fill only `adjudication`; return the file only, without raw prose.
