Adjudicate all cases in batch_003. Return only the completed reviewer_3_input.json and do not alter source or reviewer fields.
