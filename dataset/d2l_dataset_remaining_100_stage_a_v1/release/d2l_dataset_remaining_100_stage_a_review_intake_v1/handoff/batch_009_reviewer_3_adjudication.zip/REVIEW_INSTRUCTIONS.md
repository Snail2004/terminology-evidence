# Reviewer 3 Stage A adjudication

Resolve every supplied case using the D2L evidence and both independent reviews. Every R4 case requires adjudication even when Reviewers 1 and 2 agree. Fill only `adjudication`, preserve all other fields, set `review_status` and `adjudication_status` to `COMPLETE`, and return only `reviewer_3_input.json`. Candidate replacements must be objects bound to the supplied candidate ID and slot. Do not create Stage B gold or a final glossary decision.
